from django.apps import AppConfig


class MansysConfig(AppConfig):
    name = 'mansys'
